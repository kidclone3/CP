#!/bin/sh
s="I am a student"
pwd=`pwd`
ls_now=`ls`
date=`date`
echo "$s\n$pwd\n$ls_now$date"