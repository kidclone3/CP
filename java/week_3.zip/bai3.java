import java.util.Scanner;

public class bai3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 10; ++i) {
            String name = sc.nextLine();
            int age = sc.nextInt();
            double salary = sc.nextDouble();
        }
    }
}
