public class bai2 {
    public static void main(String[] args) {
        long sum = ((98 - 2) / 2 + 1) * (98 + 2) / 2;
        System.out.println(sum);
        for (int i = 1; i <= 10; ++i) {
            System.out.printf("%d\t", i);
        }
    }
}
