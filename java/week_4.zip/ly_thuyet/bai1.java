public class bai1 {
    public static void main(String[] args) {
//        int arr[] = new int [5];
//        for (int i = 0; i < 5; ++i) {
//            System.out.printf("%d ", arr[i]);
//        }
//        bai1 => chi co' dap an D sai.

//        bai2 => 00000

//        int arr1[] = new int[-10];
//        bai3 => Exception in thread "main" java.lang.NegativeArraySizeException: -10;

//        int n = 1000;
//        int[] a = new int[n*n*n*n];
//        bai4 => Exception in thread "main" java.lang.NegativeArraySizeException: -727379968

//        int[] a;
//        for (int i = 0; i < 10; i++)
//            a[i] = i * i;
//        bai5 => java: variable a might not have been initialized

//        int[] a = {1, 2, 3};
//        int[] b = {1, 2, 3};
//        System.out.println(a==b);
//        bai6 => false. vì a, b chỉ là tham chiếu => so sánh khác nhau.
    }
}
