

import java.util.Scanner;

public class Bai1_de1 {
	
	public static int[][] inputMatrix(Scanner reader){
	
		return null;
	}
	
	
	public static boolean isUpperTriangle(int[][] arr) {
		
		
		return true;
	}
	

	
	public static int[] findRows(int[][] arr) {
		
	
		return null;
	}

}
